# WordPress Theme Framework

**WordPress Theme Framework** main library by [*WebMan Design*](http://www.webmandesign.eu)

This framework, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.

For more info please visit https://github.com/webmandesign/webman-theme-framework

*(C) Copyright WebMan Design, Oliver Juhas*
